// components/study/conclusion/index.js
Component({
 
  properties: {
    wordArr: Array
  },

  data: {
    
  },

  methods: {

  }
})
