// components/user-list/index.js
Component({

  properties: {

  },

  data: {

  },

  methods: {
    showAboutUs() {
      this.triggerEvent('showAboutUs', {}, {})
    }
  }
})
