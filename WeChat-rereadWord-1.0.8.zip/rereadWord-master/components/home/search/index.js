// components/home/search/index.js
Component({
  properties: {

  },

  data: {

  },

  methods: {

  }
})
