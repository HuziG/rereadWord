// pages/user/user.js
const Page = require('../../utils/ald-stat.js').Page;

Page({

  data: {
    
  },

  onLoad: function (options) {

  }

})