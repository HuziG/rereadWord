// components/study-exam/sentence/index.js
Component({
  
  properties: {
    annotation: String,
    translation: String,
    ansRight: {
      type: Boolean,
      value: false
    }
  },

 
  data: {

  },

  observers: {
    
  },

  methods: {

  }
})
