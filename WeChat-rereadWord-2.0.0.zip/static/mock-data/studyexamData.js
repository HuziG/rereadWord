var data = [
  { word: "verify", zn: " v. 查证,核实↵n.[计算机] DOS命令 : 打开关闭在 DOS操作期间的写文件校验开关", id: 6426 },
  { word: "view", zn: " n. 视野,风景,见解,方法,检查↵vt. 把...视为,看,考虑", id: 6441 },
  { word: "wreck", zn: " n. 失事,残骸,破坏,健康受损的人↵vt. 破坏,造成...失事↵vi. 失事,营救失事物", id: 6658 },
  { word: "deliberately", zn: " adv. 慎重地,故意地", id: 7108 },
  { word: "exclusively", zn: " adv. 排他地(独占地,专门地,仅仅,只)", id: 2462 },
  { word: "forcibly", zn: " adv. 强行地，强烈地", id: 49177 },
  { word: "formerly", zn: " adv. 以前, 从前", id: 7339 },
  { word: "increasingly", zn: " adv. 逐渐地, 渐增地", id: 3407 },
  { word: "inevitably", zn: " adv. 不可避免地", id: 7564 },
  { word: "intentional", zn: " adj. 企图的, 策划的, 故意的", id: 3483 }
]

module.exports = {
  studyexam_mock_data: data
}